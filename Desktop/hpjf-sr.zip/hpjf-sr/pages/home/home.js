// pages/home/home.js

Page({

    /**
     * 页面的初始数据
     */
    data: {
        announce: '/images/home/icon_gonggao.png',
        credit_card: '/images/home/icon_xinyongka.png',
        smart_credit: '/images/home/icon_zhinengdai.png',
        credit_loan: '/images/home/icon_xinyongdai.png',
        house_loan: '/images/home/icon_dangdidai.png ',
        car_loan: '/images/home/icon_chedidai.png',
        join: '/images/home/icon_zhaoshangjiameg.png ',
        service: '/images/home/icon_shenghuofuwu.png ',
        news: '/images/home/icon_huiouxinwen.png',
        line: '/images/home/矩形 5.png',
        more: '/images/home/icon_qianjin.png'
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        // let _this = this;
        // _this.setData({
        //     navH: App.globalData.navHeight
        // })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})